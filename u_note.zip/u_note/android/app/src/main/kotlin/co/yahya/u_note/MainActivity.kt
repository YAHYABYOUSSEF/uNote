package co.yahya.u_note

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
