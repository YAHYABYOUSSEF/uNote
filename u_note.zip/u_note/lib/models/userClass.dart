class User {
  String name;
  String uni;
  String department;
  String email;
  String password;

  User({this.name, this.uni, this.department, this.email, this.password});
}
