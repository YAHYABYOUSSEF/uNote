class NoteCards {
  String text, subText, image;
  NoteCards({this.text, this.subText, this.image});
}
